# X09 AI

A black-and-white, outer-space themed AI chat app on **Cloudflare Workers**.
Visiting the URL opens the app directly — no landing page.

```
public/                  → the app (index.html, styles.css, app.js, logo.svg, favicon.svg, manifest)
src/worker.js            → Worker: /api/chat (streams from Workers AI), /api/health
wrangler.toml            → Cloudflare config (assets, AI binding, models)
.github/workflows/deploy.yml → auto-deploy on push to main
```

## Features
- Opens straight into chat, with suggested prompts
- Streaming replies (words appear as they're generated), Stop button
- Conversation history in the sidebar (saved in the visitor's browser), search, delete, grouped by date
- Fast / Deep modes (Deep uses a larger model)
- Markdown + code blocks with Copy, Copy/Retry on every reply
- Mobile drawer sidebar, installable to the home screen (web manifest)
- Shortcuts: Enter to send, Shift+Enter for a new line, ⌘/Ctrl+K new chat, Esc to stop

## Run locally
```bash
npm install
npx wrangler login
npm run dev          # http://localhost:8787  (Workers AI calls use your Cloudflare account)
```

## Deploy via GitHub → Cloudflare
1. Push this folder to a new GitHub repo (branch `main`).
2. Cloudflare → **My Profile → API Tokens → Create Token → "Edit Cloudflare Workers"** template. Copy your **Account ID** too.
3. GitHub repo → **Settings → Secrets and variables → Actions**: add `CLOUDFLARE_API_TOKEN` and `CLOUDFLARE_ACCOUNT_ID`.
4. Push to `main` → live at `https://x09-ai.<your-subdomain>.workers.dev`.

*Alternative:* Cloudflare **Workers & Pages → Create → Import a repository** (deploy command `npx wrangler deploy`).

Custom domain: Workers & Pages → x09-ai → Settings → Domains & Routes → Add.

## Models
Set in `wrangler.toml`:
- `AI_MODEL` — Fast mode (default `@cf/meta/llama-3.1-8b-instruct`)
- `AI_MODEL_DEEP` — Deep mode (default `@cf/meta/llama-3.3-70b-instruct-fp8-fast`)

Any Workers AI text-generation model works. Workers AI has a free daily allowance; heavier use is billed by Cloudflare.

## Notes
- Chat history is stored in each visitor's browser (localStorage), so it doesn't sync across devices. Add accounts + a database (e.g. Cloudflare D1) if you need that.
- The API is public; if it gets abused, add Cloudflare Turnstile or a rate-limiting rule on `/api/chat`.
