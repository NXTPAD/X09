/**
 * X09 AI — Cloudflare Worker
 * - Serves the chat app from /public (ASSETS binding)
 * - POST /api/chat   streams replies from Workers AI (Server-Sent Events)
 * - GET  /api/health status check
 */

const SYSTEM_PROMPTS = {
  fast:
    "You are X09, the AI co-pilot of X09 AI. Be concise, clear and genuinely helpful. " +
    "Use a light touch of outer-space mission-control flavor only when natural. Use Markdown for lists and code.",
  deep:
    "You are X09, the AI co-pilot of X09 AI. Think carefully and give thorough, well-structured answers with " +
    "headings, steps and examples where useful. Be accurate and say when you're unsure. Use Markdown.",
};

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  });

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/api/health") {
      return json({ ok: true, service: "x09-ai", ai: Boolean(env.AI), time: new Date().toISOString() });
    }

    if (url.pathname === "/api/chat") {
      if (request.method !== "POST") return json({ error: "Method not allowed" }, 405);

      let body;
      try { body = await request.json(); } catch { return json({ error: "Invalid JSON" }, 400); }

      const mode = body.mode === "deep" ? "deep" : "fast";
      const messages = (Array.isArray(body.messages) ? body.messages : [])
        .filter((m) => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
        .slice(-20)
        .map((m) => ({ role: m.role, content: m.content.slice(0, 6000) }));
      if (!messages.length || messages[messages.length - 1].role !== "user") {
        return json({ error: "Last message must be from the user" }, 400);
      }

      if (!env.AI) {
        return json({
          reply:
            "X09 core is online, but the AI engine isn't connected yet. Add the `[ai]` binding in `wrangler.toml` and redeploy.",
        });
      }

      const model = mode === "deep" ? env.AI_MODEL_DEEP || env.AI_MODEL : env.AI_MODEL;
      try {
        const stream = await env.AI.run(model || "@cf/meta/llama-3.1-8b-instruct", {
          messages: [{ role: "system", content: SYSTEM_PROMPTS[mode] }, ...messages],
          max_tokens: mode === "deep" ? 1500 : 700,
          stream: true,
        });
        return new Response(stream, {
          headers: {
            "content-type": "text/event-stream; charset=utf-8",
            "cache-control": "no-store",
            "x-accel-buffering": "no",
          },
        });
      } catch (err) {
        return json({ reply: "Signal lost in the nebula — the AI engine returned an error. Please try again." });
      }
    }

    // Everything else → the app (static assets; unknown paths fall back to index.html)
    return env.ASSETS.fetch(request);
  },
};
