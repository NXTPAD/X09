/* X09 AI — chat app */
(() => {
  "use strict";

  // ---------- Starfield (moving, parallax, shooting stars) ----------
  const canvas = document.getElementById("starfield");
  const ctx = canvas.getContext("2d");
  const reduceMotion = matchMedia("(prefers-reduced-motion: reduce)").matches;
  let stars = [], shooters = [], W = 0, H = 0, DPR = 1;
  let px = 0, py = 0, tx = 0, ty = 0;           // parallax (current / target)
  let last = performance.now();

  function makeStar() {
    const z = Math.random();                     // depth: 0 = far, 1 = near
    const ang = Math.random() * Math.PI * 2;
    const speed = (6 + z * 22) * DPR;            // px per second
    return {
      x: Math.random() * W, y: Math.random() * H, z,
      r: (0.3 + z * 1.3) * DPR,
      vx: Math.cos(ang) * speed, vy: Math.sin(ang) * speed,
      wob: Math.random() * 6.28, wobSpd: 0.2 + Math.random() * 0.5,
      tw: Math.random() * 6.28,
    };
  }
  function sizeStars() {
    DPR = Math.min(devicePixelRatio || 1, 2);
    W = canvas.width = innerWidth * DPR;
    H = canvas.height = innerHeight * DPR;
    const n = Math.min(420, Math.round((innerWidth * innerHeight) / 2600));
    stars = Array.from({ length: n }, makeStar);
  }
  function spawnShooter() {
    const fromLeft = Math.random() < 0.5;
    const speed = (700 + Math.random() * 500) * DPR;
    const ang = (fromLeft ? 0.35 : Math.PI - 0.35) + (Math.random() - 0.5) * 0.3;
    shooters.push({ x: fromLeft ? Math.random() * W * 0.5 : W * (0.5 + Math.random() * 0.5), y: Math.random() * H * 0.4,
      vx: Math.cos(ang) * speed, vy: Math.sin(ang) * speed, life: 1 });
  }

  function drawStars(now) {
    const dt = Math.min((now - last) / 1000, 0.05); last = now;
    ctx.clearRect(0, 0, W, H);

    // ease parallax toward pointer / tilt target
    px += (tx - px) * 0.04; py += (ty - py) * 0.04;

    ctx.fillStyle = "#fff";
    for (const s of stars) {
      if (!reduceMotion) {
        s.wob += s.wobSpd * dt;
        // gentle wandering: rotate velocity a little over time
        const turn = Math.sin(s.wob) * 0.25 * dt;
        const c = Math.cos(turn), n = Math.sin(turn);
        const vx = s.vx * c - s.vy * n; s.vy = s.vx * n + s.vy * c; s.vx = vx;
        s.x += s.vx * dt; s.y += s.vy * dt;
        const m = 20 * DPR;
        if (s.x < -m) s.x = W + m; else if (s.x > W + m) s.x = -m;
        if (s.y < -m) s.y = H + m; else if (s.y > H + m) s.y = -m;
        s.tw += dt * (1 + s.z * 2);
      }
      const ox = px * (10 + s.z * 40) * DPR, oy = py * (10 + s.z * 40) * DPR;
      ctx.globalAlpha = (0.25 + s.z * 0.6) * (reduceMotion ? 1 : 0.65 + 0.35 * Math.sin(s.tw));
      ctx.beginPath(); ctx.arc(s.x + ox, s.y + oy, s.r, 0, 6.28); ctx.fill();
      if (s.z > 0.85) {                           // soft glow on the nearest stars
        ctx.globalAlpha *= 0.15;
        ctx.beginPath(); ctx.arc(s.x + ox, s.y + oy, s.r * 4, 0, 6.28); ctx.fill();
      }
    }

    if (!reduceMotion) {
      if (Math.random() < dt * 0.25 && shooters.length < 2) spawnShooter();   // ~1 every 4s
      shooters = shooters.filter((s) => s.life > 0 && s.x > -200 && s.x < W + 200 && s.y < H + 200);
      for (const s of shooters) {
        s.x += s.vx * dt; s.y += s.vy * dt; s.life -= dt * 0.9;
        const tail = 0.12;
        const g = ctx.createLinearGradient(s.x, s.y, s.x - s.vx * tail, s.y - s.vy * tail);
        g.addColorStop(0, `rgba(255,255,255,${Math.max(s.life, 0)})`);
        g.addColorStop(1, "rgba(255,255,255,0)");
        ctx.globalAlpha = 1; ctx.strokeStyle = g; ctx.lineWidth = 1.6 * DPR; ctx.lineCap = "round";
        ctx.beginPath(); ctx.moveTo(s.x, s.y); ctx.lineTo(s.x - s.vx * tail, s.y - s.vy * tail); ctx.stroke();
      }
    }
    ctx.globalAlpha = 1;
    requestAnimationFrame(drawStars);
  }

  addEventListener("resize", sizeStars);
  addEventListener("pointermove", (e) => { tx = e.clientX / innerWidth - 0.5; ty = e.clientY / innerHeight - 0.5; });
  addEventListener("deviceorientation", (e) => {
    if (e.gamma == null) return;
    tx = Math.max(-0.5, Math.min(0.5, e.gamma / 60));
    ty = Math.max(-0.5, Math.min(0.5, (e.beta - 40) / 60));
  });
  document.addEventListener("visibilitychange", () => { last = performance.now(); });
  sizeStars(); requestAnimationFrame(drawStars);

  // ---------- Elements ----------
  const $ = (id) => document.getElementById(id);
  const els = {
    sidebar: $("sidebar"), scrim: $("scrim"), threads: $("threads"), search: $("search"),
    chat: $("chat"), empty: $("empty"), messages: $("messages"), title: $("threadTitle"),
    form: $("composer"), input: $("input"), send: $("send"), statusText: $("statusText"),
  };

  // ---------- Storage (safe) ----------
  const KEY = "x09.threads.v1";
  const store = {
    load() { try { return JSON.parse(localStorage.getItem(KEY)) || []; } catch { return []; } },
    save(v) { try { localStorage.setItem(KEY, JSON.stringify(v)); } catch {} },
  };

  let threads = store.load();          // [{id, title, messages:[{role, content}], updated}]
  let currentId = null;
  let mode = "fast";
  let controller = null;               // AbortController for streaming

  const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
  const current = () => threads.find((t) => t.id === currentId);
  const persist = () => store.save(threads);

  // ---------- Markdown (small, safe) ----------
  const esc = (s) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  function inline(s) {
    return s
      .replace(/`([^`]+)`/g, "<code>$1</code>")
      .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
      .replace(/(^|[^*])\*([^*\n]+)\*/g, "$1<em>$2</em>")
      .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  }
  function md(src) {
    const parts = src.split(/```/);
    let html = "";
    parts.forEach((part, i) => {
      if (i % 2 === 1) {
        const nl = part.indexOf("\n");
        const lang = nl > -1 ? part.slice(0, nl).trim() : "";
        const code = nl > -1 ? part.slice(nl + 1) : part;
        html += `<pre><div class="code-head"><span>${esc(lang || "code")}</span><button class="small-btn" data-copy>Copy</button></div><code>${esc(code.replace(/\n$/, ""))}</code></pre>`;
        return;
      }
      const lines = esc(part).split("\n");
      let list = null, para = [];
      const flushPara = () => { if (para.length) { html += `<p>${inline(para.join("<br>"))}</p>`; para = []; } };
      const flushList = () => { if (list) { html += `<${list.tag}>${list.items.map((x) => `<li>${inline(x)}</li>`).join("")}</${list.tag}>`; list = null; } };
      for (const line of lines) {
        let m;
        if ((m = line.match(/^\s*[-*•]\s+(.*)/))) { flushPara(); if (!list || list.tag !== "ul") { flushList(); list = { tag: "ul", items: [] }; } list.items.push(m[1]); }
        else if ((m = line.match(/^\s*\d+[.)]\s+(.*)/))) { flushPara(); if (!list || list.tag !== "ol") { flushList(); list = { tag: "ol", items: [] }; } list.items.push(m[1]); }
        else if ((m = line.match(/^#{1,4}\s+(.*)/))) { flushPara(); flushList(); html += `<h3>${inline(m[1])}</h3>`; }
        else if (!line.trim()) { flushPara(); flushList(); }
        else { flushList(); para.push(line); }
      }
      flushPara(); flushList();
    });
    return html;
  }

  // ---------- Rendering ----------
  const ICON_COPY = '<svg viewBox="0 0 24 24" width="14" height="14"><rect x="9" y="9" width="11" height="11" rx="2" stroke="currentColor" stroke-width="2" fill="none"/><path d="M5 15V5a2 2 0 0 1 2-2h8" stroke="currentColor" stroke-width="2" fill="none"/></svg>';
  const ICON_RETRY = '<svg viewBox="0 0 24 24" width="14" height="14"><path d="M4 12a8 8 0 1 0 2.3-5.6M4 4v4h4" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/></svg>';

  const fmtTime = (ts) => ts ? new Date(ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "";
  function msgEl(m) {
    const div = document.createElement("div");
    const isUser = m.role === "user";
    div.className = `msg ${isUser ? "user" : "ai"}`;
    div.innerHTML = `<div class="msg-head"><span class="who">${isUser ? "You" : "X09"}</span><span class="time">${fmtTime(m.at)}</span></div>`;
    if (isUser) {
      const b = document.createElement("div");
      b.className = "bubble"; b.textContent = m.content;
      div.appendChild(b);
    } else {
      div.insertAdjacentHTML("beforeend", `<div class="content"></div><div class="actions"><button data-act="copy">${ICON_COPY}Copy</button><button data-act="retry">${ICON_RETRY}Retry</button></div>`);
      div.querySelector(".content").innerHTML = md(m.content);
    }
    return div;
  }
  const setHome = (on) => { document.body.classList.toggle("home", on); autosize(); };

  function renderMessages() {
    const t = current();
    els.messages.innerHTML = "";
    const has = t && t.messages.length;
    setHome(!has);
    els.title.textContent = has ? t.title : "";
    if (has) t.messages.forEach((m) => els.messages.appendChild(msgEl(m)));
    scrollDown(true);
  }

  function renderThreads() {
    const q = els.search.value.trim().toLowerCase();
    const list = threads
      .filter((t) => t.messages.length && (!q || t.title.toLowerCase().includes(q) || t.messages.some((m) => m.content.toLowerCase().includes(q))))
      .sort((a, b) => b.updated - a.updated);
    els.threads.innerHTML = "";
    if (!list.length) { els.threads.innerHTML = `<div class="no-threads">${q ? "No matches." : "No missions yet. Start one below."}</div>`; return; }
    const now = new Date(); const day = 864e5;
    const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const group = (ts) => ts >= startToday ? "Today" : ts >= startToday - day ? "Yesterday" : ts >= startToday - 7 * day ? "Previous 7 days" : "Older";
    let last = "";
    for (const t of list) {
      const g = group(t.updated);
      if (g !== last) { const l = document.createElement("div"); l.className = "group-label"; l.textContent = g; els.threads.appendChild(l); last = g; }
      const b = document.createElement("button");
      b.className = "thread" + (t.id === currentId ? " active" : "");
      b.innerHTML = `<span class="t"></span><span class="del" role="button" aria-label="Delete" data-del="${t.id}"><svg viewBox="0 0 24 24" width="15" height="15"><path d="M5 7h14M10 11v6M14 11v6M6 7l1 12h10l1-12M9 7V4h6v3" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round"/></svg></span>`;
      b.querySelector(".t").textContent = t.title;
      b.addEventListener("click", (e) => {
        if (e.target.closest("[data-del]")) { deleteThread(t.id); return; }
        openThread(t.id);
      });
      els.threads.appendChild(b);
    }
  }

  function scrollDown(force) {
    const c = els.chat;
    const near = c.scrollHeight - c.scrollTop - c.clientHeight < 160;
    if (force || near) c.scrollTop = c.scrollHeight;
  }

  // ---------- Threads ----------
  function newThread() {
    stop();
    currentId = null;
    renderMessages(); renderThreads(); closeSide();
    els.input.focus();
  }
  function openThread(id) {
    stop();
    currentId = id;
    renderMessages(); renderThreads(); closeSide();
  }
  function deleteThread(id) {
    threads = threads.filter((t) => t.id !== id);
    if (currentId === id) currentId = null;
    persist(); renderMessages(); renderThreads();
  }
  function ensureThread(firstText) {
    let t = current();
    if (!t) {
      t = { id: uid(), title: firstText.replace(/\s+/g, " ").slice(0, 48) + (firstText.length > 48 ? "…" : ""), messages: [], updated: Date.now() };
      threads.push(t); currentId = t.id;
    }
    return t;
  }

  // ---------- Sending ----------
  async function send(text) {
    text = text.trim();
    if (!text || controller) return;
    const t = ensureThread(text);
    t.messages.push({ role: "user", content: text, at: Date.now() });
    t.updated = Date.now();
    persist();
    setHome(false);
    els.title.textContent = t.title;
    els.messages.appendChild(msgEl(t.messages[t.messages.length - 1]));
    renderThreads();
    await respond(t);
  }

  async function respond(t) {
    const aiMsg = { role: "assistant", content: "", at: Date.now() };
    const node = msgEl(aiMsg);
    const content = node.querySelector(".content");
    content.innerHTML = '<span class="thinking"><i></i><i></i><i></i></span>';
    els.messages.appendChild(node);
    scrollDown(true);
    setBusy(true);

    controller = new AbortController();
    let text = "";
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ messages: t.messages.slice(-20).map(({ role, content }) => ({ role, content })), mode }),
        signal: controller.signal,
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const type = res.headers.get("content-type") || "";
      if (type.includes("text/event-stream") && res.body) {
        const reader = res.body.getReader();
        const dec = new TextDecoder();
        let buf = "";
        for (;;) {
          const { value, done } = await reader.read();
          if (done) break;
          buf += dec.decode(value, { stream: true });
          const lines = buf.split("\n");
          buf = lines.pop();
          for (const line of lines) {
            if (!line.startsWith("data:")) continue;
            const data = line.slice(5).trim();
            if (!data || data === "[DONE]") continue;
            try {
              const j = JSON.parse(data);
              const piece = j.response ?? j.choices?.[0]?.delta?.content ?? "";
              if (piece) {
                text += piece;
                content.innerHTML = md(text);
                content.classList.add("cursor");
                scrollDown();
              }
            } catch {}
          }
        }
      } else {
        const j = await res.json();
        text = j.reply || "";
      }
      setOnline(true);
    } catch (err) {
      if (err.name === "AbortError") {
        text = text || "_Transmission stopped._";
      } else {
        setOnline(false);
        text = text || "Signal lost — I couldn't reach the X09 core. Check your connection and try again.";
      }
    }
    content.classList.remove("cursor");
    aiMsg.content = text || "…";
    content.innerHTML = md(aiMsg.content);
    t.messages.push(aiMsg);
    t.updated = Date.now();
    persist();
    controller = null;
    setBusy(false);
    renderThreads();
    scrollDown();
  }

  function stop() { if (controller) controller.abort(); }

  function setBusy(b) {
    els.send.classList.toggle("stop", b);
    els.send.setAttribute("aria-label", b ? "Stop" : "Send");
    els.send.disabled = !b && !els.input.value.trim();
  }
  function setOnline(ok) {
    document.querySelector(".status .pulse").classList.toggle("off", !ok);
    els.statusText.textContent = ok ? "X09 core online" : "Core unreachable";
  }

  // ---------- Events ----------
  function autosize() {
    els.input.style.height = "auto";
    els.input.style.height = Math.min(els.input.scrollHeight, 200) + "px";
    if (!controller) els.send.disabled = !els.input.value.trim();
  }
  els.input.addEventListener("input", autosize);
  els.input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); els.form.requestSubmit(); }
  });
  els.form.addEventListener("submit", (e) => {
    e.preventDefault();
    if (controller) { stop(); return; }
    const v = els.input.value;
    els.input.value = ""; autosize();
    send(v);
  });

  document.getElementById("suggestions").addEventListener("click", (e) => {
    const b = e.target.closest("button"); if (!b) return;
    send(`${b.querySelector("b").textContent} ${b.querySelector("span").textContent}`);
  });

  els.messages.addEventListener("click", async (e) => {
    const copyCode = e.target.closest("[data-copy]");
    if (copyCode) {
      const code = copyCode.closest("pre").querySelector("code").textContent;
      try { await navigator.clipboard.writeText(code); copyCode.textContent = "Copied"; setTimeout(() => (copyCode.textContent = "Copy"), 1400); } catch {}
      return;
    }
    const act = e.target.closest("[data-act]");
    if (!act) return;
    const msgs = [...els.messages.children];
    const idx = msgs.indexOf(act.closest(".msg"));
    const t = current(); if (!t) return;
    if (act.dataset.act === "copy") {
      try { await navigator.clipboard.writeText(t.messages[idx].content); act.lastChild.textContent = "Copied"; setTimeout(() => (act.lastChild.textContent = "Copy"), 1400); } catch {}
    } else if (act.dataset.act === "retry" && !controller) {
      t.messages = t.messages.slice(0, idx);
      persist(); renderMessages();
      respond(t);
    }
  });

  document.querySelectorAll(".mode button").forEach((b) =>
    b.addEventListener("click", () => {
      mode = b.dataset.mode;
      document.querySelectorAll(".mode button").forEach((x) => x.setAttribute("aria-checked", String(x === b)));
    })
  );

  $("newChat").addEventListener("click", newThread);
  $("newChatTop").addEventListener("click", newThread);
  $("clearAll").addEventListener("click", () => {
    if (!threads.length || !confirm("Delete all missions? This can't be undone.")) return;
    threads = []; currentId = null; persist(); renderMessages(); renderThreads();
  });
  els.search.addEventListener("input", renderThreads);

  const openSide = () => { els.sidebar.classList.add("open"); els.scrim.classList.add("show"); };
  function closeSide() { els.sidebar.classList.remove("open"); els.scrim.classList.remove("show"); }
  $("openSide").addEventListener("click", openSide);
  $("openSideMobile").addEventListener("click", openSide);
  $("closeSide").addEventListener("click", closeSide);
  els.scrim.addEventListener("click", closeSide);

  addEventListener("keydown", (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); newThread(); }
    if (e.key === "Escape") { closeSide(); stop(); }
  });

  // ---------- HUD clock + greeting ----------
  const clock = $("clock");
  function tickClock() {
    const d = new Date();
    clock.textContent = d.toISOString().slice(11, 19) + " UTC";
  }
  tickClock(); setInterval(tickClock, 1000);
  const hr = new Date().getHours();
  $("greeting").textContent = hr < 5 ? "Burning the midnight oil." : hr < 12 ? "Good morning." : hr < 18 ? "Good afternoon." : "Good evening.";

  // ---------- Boot ----------
  renderThreads();
  renderMessages();
  if (matchMedia("(min-width: 821px)").matches) els.input.focus();
})();
